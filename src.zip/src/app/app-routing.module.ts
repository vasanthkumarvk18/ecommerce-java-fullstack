import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductViewComponent } from './product-view/product-view.component';
import { ProductDetailComponent } from './component/product-detail/product-detail.component';
import { CartPageComponent } from './component/cart-page/cart-page.component';
import { OrderPageComponent } from './component/order-page/order-page.component';
import { ContactComponent } from './contact/contact.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { LoginComponent } from './login/login.component';
import { HomePgComponent } from './home-pg/home-pg.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { OrderDetailsComponent } from './order-details/order-details.component';

const routes: Routes = [
  {path:'contact',component:ContactComponent},
  {path:'feedback',component:FeedbackComponent},
  {path:'login',component:LoginComponent},
  {path:'homePg',component:HomePgComponent},
  {path:'register',component:RegistrationComponent},
  {path:'product-view',component:ProductViewComponent},
  {path:'product-detail/:productid',component:ProductDetailComponent},
  {path:'cart-page',component:CartPageComponent},
  {path:'order-page',component:OrderPageComponent},
  {path:'order-detail',component:OrderDetailsComponent},
  { path: 'order-detail/:productId', component: OrderDetailsComponent },
  {path:'',redirectTo:'/homePg',pathMatch:'full'},



  {path:'admin',
  loadChildren:()=>
  import('./modules/admin/admin.module').then((m)=>m.AdminModule),
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
