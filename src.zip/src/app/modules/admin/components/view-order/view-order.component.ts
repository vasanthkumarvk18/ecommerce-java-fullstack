import { Component, OnInit } from '@angular/core';
import { Order } from './order-model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.css']
})
export class ViewOrderComponent implements OnInit {
  orders: Order[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchOrders();
  }

  fetchOrders() {
    this.http.get<Order[]>('http://localhost:8084/api/v1/orderdetails/allorders').subscribe(
      (response) => {
        this.orders = response;
      },
      (error) => {
        console.error('Error fetching orders:', error);
      }
    );
  }


  deleteOrder(order: Order) {
    this.http.delete(`http://localhost:8084/api/v1/orderdetails/${order.orderid}`).subscribe(
      (response) => {
        console.log('Order deleted successfully:', response);
        this.fetchOrders(); 
      },
      (error) => {
        console.error('Error deleting order:', error);
      }
    );
  }

}

