import { Component, OnInit } from '@angular/core';
import { customer } from './customer-model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit{
  customers: customer[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchCustomers();
  }

  fetchCustomers() {
    this.http.get<customer[]>('http://localhost:8084/api/v1/register/getAllRegisters').subscribe(
      (response) => {
        this.customers = response;
      },
      (error) => {
        console.error('Error fetching customers:', error);
      }
    );
  }

}
