import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Contact } from 'src/app/contact/contact-model';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {
  
  contacts: Contact[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchContacts();
  }

  fetchContacts() {
    this.http.get<Contact[]>('http://localhost:8084/api/v1/contact/getAllcontact').subscribe(
      (response) => {
        this.contacts = response;
      },
      (error) => {
        console.error('Error fetching contacts:', error);
      }
    );
  }
}
