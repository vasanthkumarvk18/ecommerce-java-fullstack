package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.PaymentDTO;

public interface PaymentService {
    PaymentDTO processPayment(PaymentDTO paymentDTO);
    
    PaymentDTO getPaymentById(Long paymentId);
    
    List<PaymentDTO> getAllPayments();
    
    boolean deletePayment(Long paymentId);
}
