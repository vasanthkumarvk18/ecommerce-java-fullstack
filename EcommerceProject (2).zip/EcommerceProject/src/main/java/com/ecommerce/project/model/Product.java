package com.ecommerce.project.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id",length=50)
	 private long productid;
	@Column(name="Item_name",length=50)
	    private String itemname;
	@Column(name="Description",length=1000)
	    private String description;
	@Column(name="Price",length=50)
	    private int price;
	@Column(name="Quantiy",length=100)
	    private int quantity;
	@Column(name="Size",length=50)
	    private int size;
	@Column(name="Category_name",length=50)
	    private String categoryname;
	@Column(name="Image",length=200)
	    private String image;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(long productid, String itemname, String description, int price, int quantity, int size,
			String categoryname, String image) {
		super();
		this.productid = productid;
		this.itemname = itemname;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
		this.size = size;
		this.categoryname = categoryname;
		this.image = image;
	}
	public long getProductid() {
		return productid;
	}
	public void setProductid(long productid) {
		this.productid = productid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getCategoryname() {
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "Product [productid=" + productid + ", itemname=" + itemname + ", description=" + description
				+ ", price=" + price + ", quantity=" + quantity + ", size=" + size + ", categoryname=" + categoryname
				+ ", image=" + image + "]";
	}
	
}
