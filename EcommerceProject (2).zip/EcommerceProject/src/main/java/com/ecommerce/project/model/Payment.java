package com.ecommerce.project.model;
import javax.persistence.*;

@Entity
@Table(name = "payment")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Payment_Id")
    private Long paymentId;
	@Column(name="Order_Id",length=50)
    private Long orderId;
    private String paymentMethod;
    @Column(name="cardholderName",length=50)
    private String cardholderName;
    @Column(name="cardNumber",length=50)
    private String cardNumber;
    @Column(name="expirationDate")
    private String expirationDate;
    @Column(name="cvv",length=50)
    private String cvv;
	public Payment() {
		super();
		
	}
	public Payment(Long paymentId, Long orderId, String paymentMethod, String cardholderName, String cardNumber,
			String expirationDate, String cvv) {
		super();
		this.paymentId = paymentId;
		this.orderId = orderId;
		this.paymentMethod = paymentMethod;
		this.cardholderName = cardholderName;
		this.cardNumber = cardNumber;
		this.expirationDate = expirationDate;
		this.cvv = cvv;
	}
	public Long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getCardholderName() {
		return cardholderName;
	}
	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", orderId=" + orderId + ", paymentMethod=" + paymentMethod
				+ ", cardholderName=" + cardholderName + ", cardNumber=" + cardNumber + ", expirationDate="
				+ expirationDate + ", cvv=" + cvv + "]";
	}
    
    
}
