package com.ecommerce.project.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ecommerce.project.DTO.CartDTO;
import com.ecommerce.project.service.CartService;

@RestController
@RequestMapping("/api/v1/cart")
public class CartController {
	@Autowired 
	private CartService cartService;
	
	  @GetMapping("/{cartId}")
	    public ResponseEntity<CartDTO> getCartById(@PathVariable long cartId) {
	        CartDTO cartDTO = cartService.getCartById(cartId);
	        if (cartDTO != null) {
	            return ResponseEntity.ok(cartDTO);
	        }
	        return ResponseEntity.notFound().build();
	    }

	  @PostMapping("/{userId}/products/{productId}")
	    public void addProductToCart( @PathVariable long userId, @PathVariable long productId) {
	        cartService.addProductToCart(userId, productId);
	    }

	    @DeleteMapping("/{cartId}/products/{productId}")
	    public ResponseEntity<Void> removeProductFromCart(@PathVariable long cartId, @PathVariable long productId) {
	        cartService.removeProductFromCart(cartId, productId);
	        return ResponseEntity.noContent().build();
	    }

	    @DeleteMapping("/{cartId}")
	    public ResponseEntity<Void> deleteCart(@PathVariable long cartId) {
	        cartService.deleteCart(cartId);
	        return ResponseEntity.noContent().build();
	    }
	}


