package com.ecommerce.project.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.FeedbackDTO;
import com.ecommerce.project.exception.FeedbackNotFoundException;
import com.ecommerce.project.model.Feedback;
import com.ecommerce.project.repository.FeedbackRepo;

@Service
public class FeedbackServiceIMP implements FeedbackService{
	@Autowired FeedbackRepo feedbackRepo;

	@Override
	public String addFeedback(FeedbackDTO feedbackDTO) {
	    Feedback feedback = new Feedback();
	    feedback.setName(feedbackDTO.getName());
	    feedback.setEmail(feedbackDTO.getEmail());
	    feedback.setFeedback(feedbackDTO.getFeedback());
	    Feedback savedFeedback = feedbackRepo.save(feedback);
	    
	    
	    feedbackDTO.setId(savedFeedback.getId());
	    
	    return feedbackDTO.toString(); 
	}


	@Override
	public List<FeedbackDTO> getAllFeedback() {
	    List<Feedback> feedbackList = feedbackRepo.findAll();
	    List<FeedbackDTO> feedbackDTOList = new ArrayList<>();
	    
	    for (Feedback feedback : feedbackList) {
	        FeedbackDTO feedbackDTO = new FeedbackDTO(
	            feedback.getId(),
	            feedback.getName(),
	            feedback.getEmail(),
	            feedback.getFeedback()
	        );
	        feedbackDTOList.add(feedbackDTO);
	    }
	    
	    return feedbackDTOList;
	}


	@Override
	public String updateFeedback(int id, FeedbackDTO feedbackDTO) {
	    Feedback existingFeedback = feedbackRepo.findById((long) id)
	            .orElseThrow(() -> new FeedbackNotFoundException("Feedback Not Found"));
	    existingFeedback.setName(feedbackDTO.getName());
	    existingFeedback.setEmail(feedbackDTO.getEmail());
	    existingFeedback.setFeedback(feedbackDTO.getFeedback());

	    Feedback updatedFeedback = feedbackRepo.save(existingFeedback);
	    return updatedFeedback.getName();
	}




	@Override
	public boolean deleteFeedback(long id) {
	    if (feedbackRepo.existsById(id)) {
	        feedbackRepo.deleteById(id);
	        return true;
	    } else {
	        throw new FeedbackNotFoundException("Feedback Not Found");
	    }
	}

}







