package com.ecommerce.project.exception;

public class ContactNotFoundException extends RuntimeException{
	public ContactNotFoundException(String message) {
        super(message);
    }

}
