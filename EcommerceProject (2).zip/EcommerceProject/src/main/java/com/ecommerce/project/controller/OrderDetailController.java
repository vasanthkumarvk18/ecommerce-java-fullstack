package com.ecommerce.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.project.DTO.OrderDetailDTO;
import com.ecommerce.project.model.OrderDetail;
import com.ecommerce.project.service.OrderDetailService;

import java.util.List;

@RestController
@RequestMapping("/api/v1/orderdetails")
@CrossOrigin("*")
public class OrderDetailController {
	@Autowired
    private OrderDetailService orderDetailService;


    @PostMapping("/placeorder")
    public ResponseEntity<OrderDetail> placeOrder(@RequestBody OrderDetailDTO orderDetailDTO) {
        OrderDetail orderDetail = orderDetailService.placeOrder(orderDetailDTO);
        return new ResponseEntity<>(orderDetail, HttpStatus.CREATED);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDetail> getOrderDetailById(@PathVariable Long orderId) {
        OrderDetail orderDetail = orderDetailService.getorderDetailById(orderId);
        return new ResponseEntity<>(orderDetail, HttpStatus.OK);
    }

    @GetMapping("/allorders")
    public ResponseEntity<List<OrderDetail>> getAllOrderDetails() {
        List<OrderDetail> orderDetails = orderDetailService.getAllOrderDetails();
        return new ResponseEntity<>(orderDetails, HttpStatus.OK);
    }
    
    @DeleteMapping("/{orderId}")
    public ResponseEntity<Void> deleteOrderDetail(@PathVariable("orderId") Long orderId) {
        orderDetailService.deleteOrderDetail(orderId);
        return ResponseEntity.noContent().build();
    }

}

